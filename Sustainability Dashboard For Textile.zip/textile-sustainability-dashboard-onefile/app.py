
import os
import io
import json
import time
import math
import base64
import random
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple

import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

# Optional PDF export
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

APP_TITLE = "Sustainability Dashboard – Textile Manufacturing (One‑File App)"
st.set_page_config(page_title=APP_TITLE, page_icon="🧵", layout="wide")

# -------------------------
# Utilities & Persistence
# -------------------------
DATA_PATH = "data_store.parquet"
ALERTS_PATH = "alerts_store.json"
PREFS_PATH = "prefs.json"

def load_prefs():
    try:
        with open(PREFS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_prefs(obj):
    try:
        with open(PREFS_PATH, "w", encoding="utf-8") as f:
            json.dump(obj, f)
    except Exception:
        pass

def load_alerts():
    try:
        with open(ALERTS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_alerts(alerts):
    try:
        with open(ALERTS_PATH, "w", encoding="utf-8") as f:
            json.dump(alerts, f)
    except Exception:
        pass

def load_data() -> pd.DataFrame:
    if os.path.exists(DATA_PATH):
        try:
            return pd.read_parquet(DATA_PATH)
        except Exception:
            try:
                return pd.read_csv(DATA_PATH.replace(".parquet", ".csv"))
            except Exception:
                pass
    # If nothing exists, synthesize demo data (2 years, hourly granularity across units/departments/machines/shifts)
    return synthesize_data()

def save_data(df: pd.DataFrame):
    try:
        df.to_parquet(DATA_PATH, index=False)
    except Exception:
        df.to_csv(DATA_PATH.replace(".parquet", ".csv"), index=False)

def synthesize_data(seed: int = 42) -> pd.DataFrame:
    random.seed(seed); np.random.seed(seed)
    start = pd.Timestamp.today().normalize() - pd.DateOffset(years=2)
    end = pd.Timestamp.today().normalize()
    hours = pd.date_range(start, end, freq="1H", inclusive="left")

    units = ["Spinning", "Weaving", "Dyeing", "Finishing"]
    departments = ["Prod-A", "Prod-B", "Utilities", "Maintenance", "Quality"]
    machines = [f"MC-{i:02d}" for i in range(1, 13)]
    shifts = ["A", "B", "C"]

    rows = []
    for ts in hours:
        unit = random.choice(units)
        dept = random.choice(departments)
        machine = random.choice(machines)
        shift = shifts[(ts.hour // 8) % 3]

        base_energy = {"Spinning": 720, "Weaving": 680, "Dyeing": 900, "Finishing": 600}[unit]
        base_water  = {"Spinning": 3.0, "Weaving": 2.2, "Dyeing": 8.0, "Finishing": 4.0}[unit]
        base_waste  = {"Spinning": 35, "Weaving": 30, "Dyeing": 45, "Finishing": 28}[unit]
        # Emissions roughly proportional to energy with dept factor
        dept_factor = 1.0 + (departments.index(dept) - 2) * 0.03
        hour_factor = 0.85 + 0.3 * math.sin(ts.hour / 24 * 2*math.pi)
        noise = np.random.normal(0, 1)

        energy_kwh = max(50, np.random.normal(base_energy * hour_factor, 60))
        water_kl = max(0.1, np.random.normal(base_water * hour_factor, 0.7))
        waste_kg = max(1, np.random.normal(base_waste * hour_factor, 6))
        emissions_tco2e = max(0.01, energy_kwh * 0.00065 * dept_factor + noise*0.01)

        rows.append([ts, unit, dept, machine, shift, energy_kwh, water_kl, waste_kg, emissions_tco2e])

    df = pd.DataFrame(rows, columns=[
        "timestamp","unit","department","machine","shift",
        "energy_kwh","water_kl","waste_kg","emissions_tco2e"
    ])
    save_data(df)
    return df

# Targets (monthly averages)
DEFAULT_TARGETS = {
    "energy_kwh_per_hour": 700,
    "water_kl_per_hour": 4.5,
    "waste_kg_per_hour": 35,
    "emissions_tco2e_per_hour": 0.45
}

# -------------------------
# Helper functions
# -------------------------
def persist_filter_state(key, value):
    prefs = load_prefs()
    prefs[key] = value
    save_prefs(prefs)

def get_persisted(key, default):
    return load_prefs().get(key, default)

def kpi_color(current, target, inverse=False, tol=0.03):
    # inverse=False means lower is better if current <= target => green
    # inverse=True means higher is better (not used here)
    if inverse:
        good = current >= target
    else:
        good = current <= target
    if good:
        return "✅"
    # tolerance for warning
    if abs(current - target) / max(target, 1e-6) <= (0.15 + tol):
        return "🟡"
    return "🔴"

def score_overall(currs: Dict[str, float], targets: Dict[str, float]):
    # Simple additive score, 100 perfect if all meet target, degrade otherwise
    score = 0
    for k,v in currs.items():
        t = targets[k]
        ratio = v / max(t, 1e-6)
        contrib = max(0, 100 - 25 * (ratio - 1) * 100 / 100)
        contrib = min(100, contrib)
        score += contrib
    return round(score / len(currs), 1)

def anomaly_flags(series: pd.Series, z=2.5):
    s = (series - series.rolling(24, min_periods=6).mean()) / (series.rolling(24, min_periods=6).std() + 1e-9)
    return (s.abs() >= z)

def bytes_download_button(data: bytes, filename: str, label: str):
    b64 = base64.b64encode(data).decode()
    href = f'<a href="data:file/octet-stream;base64,{b64}" download="{filename}">{label}</a>'
    st.markdown(href, unsafe_allow_html=True)

# -------------------------
# Sidebar: Alerts Center
# -------------------------
def generate_alerts(df: pd.DataFrame) -> List[Dict[str, Any]]:
    # summarize last 24h vs target
    now = pd.Timestamp.now().floor("H")
    recent = df[df["timestamp"] >= now - pd.Timedelta(hours=24)]
    alerts = []

    if recent.empty:
        return alerts

    metrics = {
        "energy_kwh": DEFAULT_TARGETS["energy_kwh_per_hour"],
        "water_kl": DEFAULT_TARGETS["water_kl_per_hour"],
        "waste_kg": DEFAULT_TARGETS["waste_kg_per_hour"],
        "emissions_tco2e": DEFAULT_TARGETS["emissions_tco2e_per_hour"],
    }
    for m, t in metrics.items():
        val = recent[m].mean()
        if val > 1.2 * t:
            alerts.append({"severity":"High","message": f"{m.replace('_',' ').title()} exceeded target by {(val/t-1):.0%} (24h avg)."})
        elif val > 1.05 * t:
            alerts.append({"severity":"Medium","message": f"{m.replace('_',' ').title()} near target (+{(val/t-1):.0%})."})
    return alerts

def render_sidebar_alerts():
    st.sidebar.header("🔔 Alerts & Updates")
    alerts = load_alerts()
    if st.sidebar.button("🔄 Refresh Alerts"):
        # recompute alerts with current filters ignored (global health)
        df_all = load_data()
        alerts = generate_alerts(df_all)
        save_alerts(alerts)

    if not alerts:
        st.sidebar.success("All good. No critical alerts.")
    else:
        # Group by severity
        sev_order = {"High":0, "Medium":1, "Low":2}
        alerts_sorted = sorted(alerts, key=lambda a: sev_order.get(a.get("severity","Medium"),1))
        for a in alerts_sorted:
            if a["severity"] == "High":
                st.sidebar.error(a["message"])
            elif a["severity"] == "Medium":
                st.sidebar.warning(a["message"])
            else:
                st.sidebar.info(a["message"])

    # Sticky notes
    st.sidebar.subheader("🗒️ Notes")
    note = st.sidebar.text_input("Add a note (persists)")
    if st.sidebar.button("Add Note"):
        alerts = load_alerts()
        alerts.append({"severity":"Info", "message": f"NOTE: {note}"})
        save_alerts(alerts)
        st.sidebar.success("Note added.")

# -------------------------
# Data filtering
# -------------------------
df = load_data()

# Persisted filters
default_from = get_persisted("date_from", pd.Timestamp.today().normalize())
default_to   = get_persisted("date_to", pd.Timestamp.today().normalize() + pd.Timedelta(days=1))
default_unit = get_persisted("units", ["All"])
default_dept = get_persisted("departments", ["All"])
default_machine = get_persisted("machines", ["All"])
default_shift = get_persisted("shifts", ["All"])

with st.sidebar:
    render_sidebar_alerts()
    st.write("---")
    st.header("🔎 Filters")
    c1, c2 = st.columns(2)
    with c1:
        date_from = st.date_input("From", value=pd.to_datetime(default_from).date())
    with c2:
        date_to = st.date_input("To", value=pd.to_datetime(default_to).date())
    persist_filter_state("date_from", str(date_from))
    persist_filter_state("date_to", str(date_to))

    units = ["All"] + sorted(df["unit"].unique().tolist())
    departments = ["All"] + sorted(df["department"].unique().tolist())
    machines = ["All"] + sorted(df["machine"].unique().tolist())
    shifts = ["All"] + sorted(df["shift"].unique().tolist())

    sel_units = st.multiselect("Unit(s)", units, default=default_unit if default_unit else ["All"])
    sel_depts = st.multiselect("Department(s)", departments, default=default_dept if default_dept else ["All"])
    sel_machs = st.multiselect("Machine(s)", machines, default=default_machine if default_machine else ["All"])
    sel_shifts = st.multiselect("Shift(s)", shifts, default=default_shift if default_shift else ["All"])

    persist_filter_state("units", sel_units)
    persist_filter_state("departments", sel_depts)
    persist_filter_state("machines", sel_machs)
    persist_filter_state("shifts", sel_shifts)

    st.write("---")
    if st.button("🔃 Manual Refresh"):
        st.experimental_rerun()

# Apply filters
mask = (df["timestamp"] >= pd.Timestamp(date_from)) & (df["timestamp"] < pd.Timestamp(date_to) + pd.Timedelta(days=1))
if sel_units and "All" not in sel_units:
    mask &= df["unit"].isin(sel_units)
if sel_depts and "All" not in sel_depts:
    mask &= df["department"].isin(sel_depts)
if sel_machs and "All" not in sel_machs:
    mask &= df["machine"].isin(sel_machs)
if sel_shifts and "All" not in sel_shifts:
    mask &= df["shift"].isin(sel_shifts)

view = df.loc[mask].copy()
if view.empty:
    st.warning("No data for the selected filters. Try expanding the date range or removing some filters.")

# -------------------------
# Header & Upload
# -------------------------
st.title(APP_TITLE)
st.caption("A single-file dashboard for Energy ⚡ | Water 💧 | Waste ♻️ | Emissions 🌫️ | with alerts, drill-downs, exports, and goals tracking.")

with st.expander("📥 Upload CSV to update data (optional)"):
    st.write("Columns required: timestamp, unit, department, machine, shift, energy_kwh, water_kl, waste_kg, emissions_tco2e")
    up = st.file_uploader("Upload CSV", type=["csv"])
    if up is not None:
        try:
            new_df = pd.read_csv(up, parse_dates=["timestamp"])
            needed = {"timestamp","unit","department","machine","shift","energy_kwh","water_kl","waste_kg","emissions_tco2e"}
            if needed.issubset(set(new_df.columns)):
                merged = pd.concat([df, new_df], ignore_index=True)
                save_data(merged)
                st.success("Data appended & saved.")
                st.stop()
            else:
                st.error(f"Missing columns: {needed - set(new_df.columns)}")
        except Exception as e:
            st.error(f"Upload failed: {e}")

# -------------------------
# KPI Tiles + Overall
# -------------------------
def kpi_tile(col, title, value, unit, target, help_text):
    icon = kpi_color(value, target, inverse=False)
    col.metric(label=title, value=f"{value:,.2f} {unit}", help=f"Target: {target} {unit}\n{help_text}")
    col.write(icon)

def latest_hourly_means(df_: pd.DataFrame) -> Dict[str, float]:
    if df_.empty:
        return {
            "energy_kwh_per_hour": np.nan,
            "water_kl_per_hour": np.nan,
            "waste_kg_per_hour": np.nan,
            "emissions_tco2e_per_hour": np.nan,
        }
    # hourly average over selected period
    return {
        "energy_kwh_per_hour": df_["energy_kwh"].mean(),
        "water_kl_per_hour": df_["water_kl"].mean(),
        "waste_kg_per_hour": df_["waste_kg"].mean(),
        "emissions_tco2e_per_hour": df_["emissions_tco2e"].mean(),
    }

currs = latest_hourly_means(view)
c1, c2, c3, c4, c5 = st.columns([1,1,1,1,1.2])

with c1:
    kpi_tile(st, "Energy", currs["energy_kwh_per_hour"], "kWh/h", DEFAULT_TARGETS["energy_kwh_per_hour"], "Average over selected period.")
with c2:
    kpi_tile(st, "Water", currs["water_kl_per_hour"], "kL/h", DEFAULT_TARGETS["water_kl_per_hour"], "Average over selected period.")
with c3:
    kpi_tile(st, "Waste", currs["waste_kg_per_hour"], "kg/h", DEFAULT_TARGETS["waste_kg_per_hour"], "Average over selected period.")
with c4:
    kpi_tile(st, "Emissions", currs["emissions_tco2e_per_hour"], "tCO2e/h", DEFAULT_TARGETS["emissions_tco2e_per_hour"], "Average over selected period.")
with c5:
    overall_score = score_overall(currs, DEFAULT_TARGETS) if not view.empty else 0
    st.metric("Overall Performance", f"{overall_score}/100", help="Simple composite score vs targets.")

    # Radar-like chart using Plotly polar
    fig = go.Figure()
    cats = ["Energy","Water","Waste","Emissions"]
    vals = [
        currs["energy_kwh_per_hour"]/DEFAULT_TARGETS["energy_kwh_per_hour"],
        currs["water_kl_per_hour"]/DEFAULT_TARGETS["water_kl_per_hour"],
        currs["waste_kg_per_hour"]/DEFAULT_TARGETS["waste_kg_per_hour"],
        currs["emissions_tco2e_per_hour"]/DEFAULT_TARGETS["emissions_tco2e_per_hour"],
    ]
    fig.add_trace(go.Scatterpolar(r=vals, theta=cats, fill='toself', name='Current/Target'))
    fig.update_traces(showlegend=False)
    fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), polar=dict(radialaxis=dict(visible=True, range=[0, 2])))
    st.plotly_chart(fig, use_container_width=True)

# Click-to-Explore via selection
st.write("---")
page = st.segmented_control("Explore", options=["Overall Insights","Energy","Water","Waste","Emissions"], default="Overall Insights")

# -------------------------
# Shared charts utilities
# -------------------------
def time_agg(df_, freq="D"):
    if df_.empty: 
        return df_.copy()
    g = df_.set_index("timestamp").groupby([pd.Grouper(freq=freq)]).agg({
        "energy_kwh":"sum","water_kl":"sum","waste_kg":"sum","emissions_tco2e":"sum"
    }).reset_index()
    return g

def hotspots(df_, metric: str, by: str, top_n=10):
    if df_.empty: return pd.DataFrame(columns=[by, metric])
    return df_.groupby(by)[metric].mean().sort_values(ascending=False).head(top_n).reset_index()

def render_trend(df_, metric: str, freq="D"):
    ts = time_agg(df_, freq=freq)
    if ts.empty:
        st.info("No data for chart.")
        return
    fig = px.line(ts, x="timestamp", y=metric, title=f"{metric} trend ({freq})")
    st.plotly_chart(fig, use_container_width=True)

def render_anomalies(df_, metric: str, freq="H"):
    ts = time_agg(df_, freq=freq)
    if ts.empty:
        st.info("No data for anomalies.")
        return
    ts["is_anom"] = anomaly_flags(ts[metric])
    fig = px.bar(ts, x="timestamp", y=metric, title=f"Anomalies flagged in {metric}", color=ts["is_anom"].map({True:"Anomaly", False:"Normal"}))
    st.plotly_chart(fig, use_container_width=True)

def render_hotspots(df_, metric: str):
    c1, c2, c3 = st.columns(3)
    with c1:
        by="unit"; hs = hotspots(df_, metric, by)
        fig = px.bar(hs, x=by, y=metric, title=f"Hotspots by {by}")
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        by="department"; hs = hotspots(df_, metric, by)
        fig = px.bar(hs, x=by, y=metric, title=f"Hotspots by {by}")
        st.plotly_chart(fig, use_container_width=True)
    with c3:
        by="shift"; hs = hotspots(df_, metric, by)
        fig = px.bar(hs, x=by, y=metric, title=f"Hotspots by {by}")
        st.plotly_chart(fig, use_container_width=True)

def render_goals(metric: str, current_per_hour: float, target_per_hour: float):
    if math.isnan(current_per_hour): 
        st.info("No data to show goals.")
        return
    progress = min(1.0, target_per_hour / max(current_per_hour, 1e-6)) if current_per_hour>0 else 1.0
    st.write(f"**Target:** ≤ {target_per_hour:.2f} per hour • **Current:** {current_per_hour:.2f} per hour")
    st.progress(progress, text=f"Progress towards target: {progress*100:.0f}%")
    st.caption("Lower is better for all four KPIs.")

def render_cost_impact(df_, metric: str):
    if df_.empty:
        st.info("No data for cost impact.")
        return
    # Simple cost assumptions
    costs = {"energy_kwh": 7.5, "water_kl": 35.0, "waste_kg": 4.0, "emissions_tco2e": 2000.0}  # local currency/unit
    ts = time_agg(df_, "D")
    ts["cost"] = ts[metric] * costs[metric]
    fig = px.area(ts, x="timestamp", y="cost", title=f"Cost impact of {metric}")
    st.plotly_chart(fig, use_container_width=True)

def render_compare(df_, metric: str, by: str):
    cmp = df_.groupby([by, pd.Grouper(key="timestamp", freq="M")])[metric].sum().reset_index()
    if cmp.empty:
        st.info("No data for comparison.")
        return
    fig = px.bar(cmp, x="timestamp", y=metric, color=by, barmode="group", title=f"{metric} by {by} (Monthly)")
    st.plotly_chart(fig, use_container_width=True)

# -------------------------
# Exports
# -------------------------
def export_current_view(df_):
    # CSV & Excel of filtered data
    csv_bytes = df_.to_csv(index=False).encode()
    xlsx_buf = io.BytesIO()
    with pd.ExcelWriter(xlsx_buf, engine="xlsxwriter") as writer:
        df_.to_excel(writer, index=False, sheet_name="data")
    xlsx_bytes = xlsx_buf.getvalue()

    st.download_button("⬇️ Export CSV (filtered)", data=csv_bytes, file_name="sustainability_filtered.csv", mime="text/csv")
    st.download_button("⬇️ Export Excel (filtered)", data=xlsx_bytes, file_name="sustainability_filtered.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

def export_pdf_summary(df_, title="Sustainability Summary"):
    if not REPORTLAB_AVAILABLE:
        st.info("PDF export requires reportlab. Please ensure it's installed from requirements.")
        return
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4

    c.setTitle(title)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(2*cm, height-2*cm, title)

    c.setFont("Helvetica", 10)
    y = height - 3*cm
    def line(txt):
        nonlocal y
        if y < 2*cm:
            c.showPage(); y = height - 2*cm
        c.drawString(2*cm, y, txt); y -= 0.6*cm

    line(f"Date range: {pd.to_datetime(get_persisted('date_from', str(pd.Timestamp.today().date()))).date()} to {pd.to_datetime(get_persisted('date_to', str(pd.Timestamp.today().date()))).date()}")
    line(f"Units: {', '.join(get_persisted('units', ['All']))}")
    line(f"Departments: {', '.join(get_persisted('departments', ['All']))}")
    line(f"Machines: {', '.join(get_persisted('machines', ['All']))}")
    line(f"Shifts: {', '.join(get_persisted('shifts', ['All']))}")
    line(" ")

    # KPIs
    currs = latest_hourly_means(df_)
    t = DEFAULT_TARGETS
    line("KPIs (avg per hour over filtered range):")
    line(f" - Energy: {currs['energy_kwh_per_hour']:.2f} kWh/h (Target ≤ {t['energy_kwh_per_hour']})")
    line(f" - Water: {currs['water_kl_per_hour']:.2f} kL/h (Target ≤ {t['water_kl_per_hour']})")
    line(f" - Waste: {currs['waste_kg_per_hour']:.2f} kg/h (Target ≤ {t['waste_kg_per_hour']})")
    line(f" - Emissions: {currs['emissions_tco2e_per_hour']:.2f} tCO2e/h (Target ≤ {t['emissions_tco2e_per_hour']})")
    line(" ")

    # Hotspots
    line("Top hotspots (mean by Unit):")
    hs = hotspots(df_, "energy_kwh", "unit", 5)
    for _, r in hs.iterrows():
        line(f" - {r['unit']}: {r['energy_kwh']:.1f} kWh/h")

    c.showPage()
    c.save()
    pdf_bytes = buf.getvalue()
    st.download_button("⬇️ Export PDF Summary", data=pdf_bytes, file_name="sustainability_summary.pdf", mime="application/pdf")

# -------------------------
# INSIGHTS PAGES
# -------------------------
def insights_overall():
    st.subheader("📊 Overall Insights")
    # Multi-KPI trends
    freq = st.selectbox("Trend frequency", ["D","W","M","Q","Y"], index=2, help="D=Daily, W=Weekly, M=Monthly...")
    ts = time_agg(view, freq=freq)
    if not ts.empty:
        fig = go.Figure()
        for m, label in [("energy_kwh","Energy"),("water_kl","Water"),("waste_kg","Waste"),("emissions_tco2e","Emissions")]:
            fig.add_trace(go.Scatter(x=ts["timestamp"], y=ts[m], mode="lines", name=label))
        fig.update_layout(title=f"Overall Trends ({freq})", xaxis_title="Time", yaxis_title="Sum")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No data for trend.")

    st.markdown("### 🔴 Anomalies")
    render_anomalies(view, "energy_kwh", freq="H")

    st.markdown("### 🔥 Hotspots")
    render_hotspots(view, "energy_kwh")

    st.markdown("### 🎯 Goals Progress")
    render_goals("overall", np.nanmean(list(currs.values())), np.nanmean(list(DEFAULT_TARGETS.values())))

    st.markdown("### 🧾 Cost Impact (Energy)")
    render_cost_impact(view, "energy_kwh")

    st.markdown("### ↔️ Comparison (Units)")
    render_compare(view, "energy_kwh", by="unit")

    st.markdown("### ⬇️ Export")
    export_current_view(view)
    export_pdf_summary(view)

def insights_metric(metric_key: str, nice_name: str, unit_label: str, target_key: str):
    st.subheader(f"{nice_name} Insights")
    freq = st.selectbox("Trend frequency", ["D","W","M","Q","Y"], index=2, key=f"freq_{metric_key}")
    render_trend(view, metric_key, freq=freq)

    st.markdown("### 🔴 Anomalies")
    render_anomalies(view, metric_key, freq="H")

    st.markdown("### 🔥 Hotspots")
    render_hotspots(view, metric_key)

    st.markdown("### 🎯 Goals Progress")
    render_goals(metric_key, currs[f"{metric_key.replace(metric_key, metric_key)}_per_hour"] if f"{metric_key}_per_hour" in currs else view[metric_key].mean(), DEFAULT_TARGETS[target_key])

    st.markdown("### 🧾 Cost Impact")
    render_cost_impact(view, metric_key)

    st.markdown("### ↔️ Comparison (Departments)")
    render_compare(view, metric_key, by="department")

    st.markdown("### ⬇️ Export")
    export_current_view(view)
    export_pdf_summary(view)

if page == "Overall Insights":
    insights_overall()
elif page == "Energy":
    insights_metric("energy_kwh", "Energy", "kWh", "energy_kwh_per_hour")
elif page == "Water":
    insights_metric("water_kl", "Water", "kL", "water_kl_per_hour")
elif page == "Waste":
    insights_metric("waste_kg", "Waste", "kg", "waste_kg_per_hour")
elif page == "Emissions":
    insights_metric("emissions_tco2e", "Emissions", "tCO2e", "emissions_tco2e_per_hour")

st.write("---")
st.caption("Built for Heads of Sustainability: clear KPIs, drill-downs, hotspots, anomalies, comparisons, goals, and exports. Single-file Streamlit app.")

