# 🧵 Sustainability Dashboard – Textile Manufacturing (Single-File App)

A **single-file Streamlit dashboard** for a textile manufacturing company's Head of Sustainability to monitor **Energy, Water, Waste, Emissions**, with filters, drill-down insights, alerts, hotspots, anomalies, comparisons, goals tracking, and exports (CSV/Excel/PDF).

## ✨ Features (Mapped to Requirements)
- **Filters & Defaults**: date, unit, department, machine, shift (persisted locally).
- **KPI & Overall Tiles**: 4 KPI tiles + Overall Performance (radar-style chart).
- **Click-to-Explore**: segmented control to open detailed insights pages.
- **Alerts Panel**: sidebar "🔔 Alerts & Updates" with auto/refresh and sticky notes.
- **Insights Pages**: trends, anomalies, hotspots, goals progress, cost impact, comparisons.
- **Graphs & Comparisons**: line, bar, area; choose frequencies (D/W/M/Q/Y).
- **Goals Tracker**: progress vs targets; simple composite score.
- **Export & Reporting**: CSV, Excel, and PDF summary.
- **Refresh**: manual refresh button; data can be updated via CSV upload.
- **Mobile-Friendly**: Streamlit responsive layout.

## 🚀 Run Locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## 🔧 Data
- App ships with **synthetic demo data** (2 years of hourly readings) across units/departments/machines/shifts.
- You can **upload CSV** to append more records. Required columns:
  `timestamp, unit, department, machine, shift, energy_kwh, water_kl, waste_kg, emissions_tco2e`

## 🧮 Targets
Default per-hour targets (edit inside `app.py` if needed):
- Energy: 700 kWh/h
- Water: 4.5 kL/h
- Waste: 35 kg/h
- Emissions: 0.45 tCO2e/h

## 📤 Exports
- CSV & Excel of the **filtered view**.
- **PDF summary** (requires `reportlab`).

## 📝 Notes
- Filters persist via a small `prefs.json` and alerts via `alerts_store.json` in the app directory.
- Data persists in `data_store.parquet` (falls back to CSV if Parquet support is unavailable).

## 🧱 Tech Stack
- Python, Streamlit, Pandas, Plotly
- ReportLab (optional, for PDF)
- Parquet (pyarrow) optional; falls back to CSV

## 🧪 Extend (Good-to-Have)
- Event overlays: add a table of events and annotate charts.
- Action tracker: create simple task objects and persist in JSON.
- Email summaries: schedule a weekly job with cron / APScheduler.
- Custom alerts/rules: store user-defined thresholds in JSON or a DB.
- Audit logs: append user actions to a log file.

## ⚠️ Known Limitations
- Designed as a single-file demo; for production, split into modules and use a DB.
- Anomaly detection is a simple rolling z-score (tune thresholds per site).
- PDF export is minimal; add visuals if needed.

---

© 2025 – MIT License
