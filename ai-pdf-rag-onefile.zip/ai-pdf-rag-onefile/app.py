
import os
import io
import time
import json
import hashlib
from typing import List, Dict, Any, Tuple

import streamlit as st

# PDF parsing
import pdfplumber

# Embeddings
from sentence_transformers import SentenceTransformer

# Vector DB (Chroma for local persistence)
import chromadb
from chromadb.config import Settings

# Optional: OpenAI for generation (if OPENAI_API_KEY is set)
USE_OPENAI = False
try:
    from openai import OpenAI
    if os.getenv("OPENAI_API_KEY"):
        client = OpenAI()
        USE_OPENAI = True
except Exception:
    USE_OPENAI = False

# Optional local LLM fallback via transformers (small model)
TRANSFORMERS_FALLBACK = True
GEN_PIPELINE = None
if not USE_OPENAI:
    try:
        from transformers import pipeline
        # Small instruct-capable or t5 model for local text generation
        # flan-t5-small is light and commonly available
        GEN_PIPELINE = pipeline("text2text-generation", model="google/flan-t5-small")
    except Exception:
        TRANSFORMERS_FALLBACK = False

# ---------------------------
# Utility: Chunking function
# ---------------------------
def chunk_text(text: str, max_chars: int = 1000, overlap: int = 100) -> List[str]:
    # Split by paragraphs first
    paras = [p.strip() for p in text.split("\n") if p.strip()]
    chunks = []
    buff = ""
    for p in paras:
        if len(buff) + len(p) + 1 <= max_chars:
            buff = (buff + "\n" + p).strip()
        else:
            if buff:
                chunks.append(buff)
            # start new with overlap from previous
            if overlap > 0 and chunks:
                tail = chunks[-1][-overlap:]
                buff = (tail + "\n" + p).strip()
            else:
                buff = p
    if buff:
        chunks.append(buff)
    return chunks

# ---------------------------
# Embedding + Vector Store
# ---------------------------
class VectorStore:
    def __init__(self, persist_dir: str = "./chroma_db"):
        os.makedirs(persist_dir, exist_ok=True)
        self.client = chromadb.Client(
            Settings(
                chroma_db_impl="duckdb+parquet",
                persist_directory=persist_dir,
            )
        )
        self.collection = self.client.get_or_create_collection(name="pdf_chunks")
        self.model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    def _id(self, meta: Dict[str, Any], text: str) -> str:
        h = hashlib.sha256()
        h.update(text.encode("utf-8"))
        h.update(json.dumps(meta, sort_keys=True).encode("utf-8"))
        return h.hexdigest()

    def add(self, docs: List[str], metas: List[Dict[str, Any]]):
        embeddings = self.model.encode(docs, show_progress_bar=False).tolist()
        ids = [self._id(m, d) for m, d in zip(metas, docs)]
        self.collection.add(documents=docs, metadatas=metas, ids=ids, embeddings=embeddings)
        self.client.persist()

    def query(self, q: str, k: int = 5) -> Tuple[List[str], List[Dict[str, Any]]]:
        q_emb = self.model.encode([q], show_progress_bar=False).tolist()[0]
        res = self.collection.query(query_embeddings=[q_emb], n_results=k)
        docs = res.get("documents", [[]])[0]
        metas = res.get("metadatas", [[]])[0]
        return docs, metas

# ---------------------------
# PDF -> Chunks ingestion
# ---------------------------
def extract_pdf_text(file: io.BytesIO) -> List[Tuple[int, str]]:
    """Returns list of (page_number, text) tuples (1-indexed pages)."""
    pages = []
    with pdfplumber.open(file) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            txt = page.extract_text() or ""
            pages.append((i, txt))
    return pages

def ingest_pdfs(store: VectorStore, uploads: List[Any], namespace: str):
    total_chunks = 0
    for up in uploads:
        name = up.name
        pages = extract_pdf_text(up)
        for pgno, ptext in pages:
            if not ptext.strip():
                continue
            for chunk in chunk_text(ptext):
                meta = {
                    "source": name,
                    "page": pgno,
                    "namespace": namespace,
                }
                store.add([chunk], [meta])
                total_chunks += 1
    return total_chunks

# ---------------------------
# RAG Answering
# ---------------------------
SYSTEM_PROMPT = """You are a precise assistant. Answer using ONLY the provided context.
If the answer cannot be found in the context, say "I cannot find this in the uploaded documents.".
Keep answers concise and cite the source filename(s) and page number(s) at the end.
"""

def build_prompt(question: str, contexts: List[Tuple[str, Dict[str, Any]]]) -> str:
    ctx_blocks = []
    for text, meta in contexts:
        ctx_blocks.append(f"[{meta.get('source')} | page {meta.get('page')}]\\n{text}")
    ctx_str = "\\n\\n".join(ctx_blocks)
    prompt = f"""{SYSTEM_PROMPT}

Context:
{ctx_str}

Question: {question}
Answer:"""
    return prompt

def generate_answer(question: str, contexts: List[Tuple[str, Dict[str, Any]]]) -> str:
    prompt = build_prompt(question, contexts)

    if USE_OPENAI:
        # OpenAI responses (GPT-4o-mini or gpt-3.5-turbo compatible)
        try:
            resp = client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.0,
                max_tokens=500,
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            return f"(OpenAI generation failed: {e})"

    # Local fallback with transformers text2text
    if TRANSFORMERS_FALLBACK and GEN_PIPELINE:
        try:
            out = GEN_PIPELINE(prompt, max_new_tokens=256, do_sample=False)
            return out[0]["generated_text"].strip()
        except Exception as e:
            pass

    # Last-resort: return concatenated contexts
    joined = "\\n\\n---\\n\\n".join(
        [f"{m.get('source')} (p.{m.get('page')}):\\n{t}" for t, m in contexts]
    )
    return f"Context-only fallback (no generator available).\\n\\n{joined}"

# ---------------------------
# Streamlit UI
# ---------------------------
st.set_page_config(page_title="AI PDF RAG (One-File)", page_icon="📄", layout="wide")
st.title("📄 AI PDF Q&A (Single-File App)")

with st.expander("ℹ️ About this app"):
    st.markdown("""
This single-file app lets you:
- **Upload** one or more PDFs
- **Embed & store** them in a local **ChromaDB** (persistent)
- **Ask questions** and get answers using **RAG**
- **See the context and sources** (file + page)
- Optional: **OpenAI** generation if `OPENAI_API_KEY` is set. Otherwise it falls back to a small local model.
    """)

# Initialize vector store (persist across reruns)
if "store" not in st.session_state:
    st.session_state.store = VectorStore(persist_dir="./chroma_db")

store: VectorStore = st.session_state.store

# Namespace (so different projects don't collide)
namespace = st.text_input("Project Namespace (keeps your data separated):", value="default")

# PDF upload
uploads = st.file_uploader("Upload PDF files", type=["pdf"], accept_multiple_files=True)
if uploads and st.button("Ingest PDFs"):
    with st.spinner("Extracting and embedding..."):
        chunks = ingest_pdfs(store, uploads, namespace=namespace)
    st.success(f"Ingested {chunks} chunks from {len(uploads)} PDF(s).")

# Query UI
st.subheader("Ask a question")
query = st.text_input("Your question:", value="")
k = st.slider("How many chunks to retrieve", min_value=2, max_value=10, value=5)

if st.button("Search & Answer") and query.strip():
    with st.spinner("Retrieving..."):
        docs, metas = store.query(f"[{namespace}] {query}", k=k)  # light namespacing in query
        contexts = list(zip(docs, metas))

    st.write("### Answer")
    answer = generate_answer(query, contexts)
    st.write(answer)

    # Show sources
    if contexts:
        st.write("### Sources & Context")
        for i, (text, meta) in enumerate(contexts, start=1):
            with st.expander(f"{i}. {meta.get('source')} — page {meta.get('page')}"):
                st.write(text)

st.divider()
st.caption("Persistent DB path: `./chroma_db`  •  Embeddings: all-MiniLM-L6-v2  •  Vector DB: Chroma  •  PDF parser: pdfplumber")
