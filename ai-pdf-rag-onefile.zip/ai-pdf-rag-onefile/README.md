# 📄 AI PDF Q&A – Single-File RAG App

An **AI-powered PDF question-answering system** in a single Python file (`app.py`).  
It supports multi-PDF upload, text extraction, intelligent chunking, embedding with Sentence-Transformers, persistent local vector search with **ChromaDB**, and Retrieval-Augmented Generation (RAG).

## ✨ Features
- Upload **multiple PDFs**.
- Extract & chunk text (**paragraph-aware** with overlap).
- Generate embeddings via **all-MiniLM-L6-v2**.
- Store & search in **ChromaDB** (local, persistent).
- Ask questions in natural language.
- **RAG generation**:
  - Uses **OpenAI** (if `OPENAI_API_KEY` is set).
  - Falls back to a small local model (**google/flan-t5-small** via `transformers`) if OpenAI is unavailable.
  - Final fallback shows context-only answer.
- Show **source filenames and page numbers** for each context chunk.
- Project **namespace** to keep datasets separate.
- Streamlit UI; can also run headless via CLI-style params if you adapt `app.py` (kept minimal here).

## 🧱 Tech Stack
- **Python**
- **Streamlit** (UI)
- **pdfplumber** (PDF parsing)
- **sentence-transformers** (embeddings)
- **ChromaDB** (vector database, local persistence)
- **OpenAI** (optional generation) / **Transformers** fallback

## 🚀 Quickstart

```bash
# 1) Create environment (recommended)
python -m venv .venv
# On Windows: .venv\Scripts\activate
# On macOS/Linux:
source .venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) (Optional) Use OpenAI for best answers
export OPENAI_API_KEY=YOUR_KEY_HERE
# Optionally choose a model (default: gpt-4o-mini)
export OPENAI_MODEL=gpt-4o-mini

# 4) Run the app
streamlit run app.py
```

Then open the local URL Streamlit shows (usually http://localhost:8501), upload PDFs, ingest, and ask questions.

## 🗂️ Persistence
ChromaDB data is saved in `./chroma_db`. You can safely delete this folder to reset the index.

## 🧪 Notes & Tips
- For large PDFs, ingestion may take time; chunking keeps memory usage sane.
- The **Namespace** box lets you keep different datasets isolated in the same DB.
- If you prefer FAISS or Pinecone/Weaviate, you can swap out the `VectorStore` implementation in `app.py`.

## 🧰 Bonus Ideas (extend yourself)
- Add audio input (speech-to-text) with `whisper` or browser-based components.
- Highlight matched spans on the page (Store page text offsets in metadata).
- Dockerize:
  ```Dockerfile
  FROM python:3.11-slim
  WORKDIR /app
  COPY . .
  RUN pip install --no-cache-dir -r requirements.txt
  EXPOSE 8501
  CMD ["streamlit", "run", "app.py", "--server.port=8501", "--server.address=0.0.0.0"]
  ```
- Write tests for chunking/ingestion (`pytest`).

## 📎 Sample PDFs
A tiny sample is included in `sample_pdfs/sample.pdf` for quick sanity checks.

## ⚠️ Known Limitations
- Local fallback model is small; answers may be concise. For best results, set `OPENAI_API_KEY`.
- PDF extraction quality depends on the PDF content (scanned images require OCR—add `pytesseract` for that).

---

© 2025 – MIT License. Enjoy!
